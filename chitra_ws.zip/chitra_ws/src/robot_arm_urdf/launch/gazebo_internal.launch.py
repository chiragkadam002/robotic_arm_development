# The final, correct internal launch file for the URDF package.

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.actions import Node

def generate_launch_description():

    # --- Paths and Packages ---
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    pkg_robot_arm_urdf = get_package_share_directory('robot_arm_urdf')

    # --- Controller Configuration Path ---
    # Define the path to the correct YAML file within this package.
    robot_controllers_path = PathJoinSubstitution([
        pkg_robot_arm_urdf, # Assumes the config folder is in this package
        "config",
        "joint_names_robot_arm_urdf.yaml", # The correct filename you specified
    ])

    # --- Robot Description ---
    # This command now correctly passes the required 'controller_config_path' argument to xacro.
    robot_description_content = Command([
        'xacro ',
        PathJoinSubstitution([pkg_robot_arm_urdf, 'urdf', 'robot_arm_urdf.urdf']),
        ' controller_config_path:=',
        robot_controllers_path
    ])
    robot_description = {'robot_description': robot_description_content}

    # --- Gazebo Environment ---
    # This correctly sets the environment variable so Gazebo can find your .STL files.
    install_dir = os.path.join(pkg_robot_arm_urdf, '..')
    gazebo_model_path = os.environ.get('GAZEBO_MODEL_PATH', '')
    if install_dir not in gazebo_model_path:
        new_gazebo_model_path = install_dir + os.pathsep + gazebo_model_path
    else:
        new_gazebo_model_path = gazebo_model_path

    set_gazebo_model_path = SetEnvironmentVariable(
        'GAZEBO_MODEL_PATH', new_gazebo_model_path
    )
    
    # --- Gazebo Launch ---
    gazebo_server_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
        )
    )
    gazebo_client_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
        )
    )

    # --- ROS 2 Nodes ---
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='both',
        parameters=[robot_description, {'use_sim_time': True}]
    )

    spawn_entity_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'robot_arm_urdf'],
        output='screen'
    )
    
    # --- Assemble the Launch Description ---
    return LaunchDescription([
        set_gazebo_model_path,
        gazebo_server_launch,
        gazebo_client_launch,
        robot_state_publisher_node,
        spawn_entity_node,
    ])