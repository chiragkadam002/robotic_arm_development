import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

# The new import that is required
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():

    # Define the path to the RViz config file
    rviz_config_path = PathJoinSubstitution([
        FindPackageShare('robot_arm_urdf'),
        'urdf',
        'robot_arm_urdf.rviz'
    ])

    # Define the robot_description parameter using Command and ParameterValue
    robot_description = ParameterValue(
        Command([
            'xacro ',
            PathJoinSubstitution([
                FindPackageShare('robot_arm_urdf'),
                'urdf',
                'robot_arm_urdf.urdf'
            ])
        ]),
        value_type=str
    )

    return LaunchDescription([
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_description}] # Pass the wrapped parameter
        ),

        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            output='screen'
        ),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_path],
            output='screen'
        )
    ])