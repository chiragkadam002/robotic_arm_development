#!/bin/bash
# This script correctly sets the environment and launches the robot.
source /opt/ros/humble/setup.bash
source ~/chitra_ws/install/setup.bash

# 1. Source the workspace if it's not already sourced
if [ -z "$AMENT_PREFIX_PATH" ]; then
    echo "Sourcing ROS 2 environment..."
    source ~/chitra_ws/install/setup.bash
fi

# 2. Export the model path that is proven to work
echo "Exporting Gazebo model path..."
export GAZEBO_MODEL_PATH=~/chitra_ws/install/robot_arm_urdf/share:$GAZEBO_MODEL_PATH

# 3. Launch the internal launch file
echo "Launching Gazebo..."
ros2 launch robot_arm_urdf gazebo_internal.launch.py
