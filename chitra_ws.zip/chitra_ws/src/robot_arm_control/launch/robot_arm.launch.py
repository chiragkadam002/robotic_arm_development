import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():

    # --- Paths and Packages ---
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')
    pkg_robot_arm_urdf = get_package_share_directory('robot_arm_urdf')
    pkg_robot_arm_control = get_package_share_directory('robot_arm_control')

    # --- Controller Configuration ---
    # Find the YAML file with our controller configurations
    # This is the crucial step: loading the controller config path
    robot_controllers_path = PathJoinSubstitution([
        pkg_robot_arm_control,
        "config",
        "arm_controllers.yaml",
    ])

    # --- Robot Description (URDF from xacro) ---
    # We now pass the controller config path into the xacro file
    robot_description_content = Command([
        'xacro ',
        PathJoinSubstitution([pkg_robot_arm_urdf, 'urdf', 'robot_arm_urdf.urdf']),
        ' controller_config_path:=',
        robot_controllers_path
    ])
    robot_description = {'robot_description': robot_description_content}

    # --- Gazebo Launch ---
    # Start Gazebo server
    gazebo_server_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
        )
    )

    # Start Gazebo client
    gazebo_client_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
        )
    )

    # --- ROS 2 Nodes ---

    # ROBOT STATE PUBLISHER
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='both',
        parameters=[robot_description]
    )

    # SPAWN ENTITY
    # This node spawns the robot model in Gazebo from the 'robot_description' topic
    spawn_entity_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=['-topic', 'robot_description', '-entity', 'robot_arm_urdf'],
        output='screen'
    )

    # JOINT STATE BROADCASTER Spawner
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
    )

    # JOINT TRAJECTORY CONTROLLER Spawner
    joint_trajectory_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_trajectory_controller", "--controller-manager", "/controller_manager"],
    )

    # --- Assemble the Launch Description ---
    return LaunchDescription([
        gazebo_server_launch,
        gazebo_client_launch,
        robot_state_publisher_node,
        spawn_entity_node,
        joint_state_broadcaster_spawner,
        joint_trajectory_controller_spawner,
    ])