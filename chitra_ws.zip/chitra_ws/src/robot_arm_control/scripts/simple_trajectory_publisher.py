#!/usr/bin/env python3

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration


class SimpleTrajectoryPublisher(Node):
    """
    This node sends a simple, hardcoded trajectory to the joint_trajectory_controller.
    """

    def __init__(self):
        super().__init__('simple_trajectory_publisher')
        
        self._action_client = ActionClient(
            self, FollowJointTrajectory, '/joint_trajectory_controller/follow_joint_trajectory')

    def send_goal(self):
        self.get_logger().info('Waiting for action server...')
        self._action_client.wait_for_server()

        self.get_logger().info('Action server found, sending goal.')

        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory.joint_names = [
            'joint_1', 'joint_2', 'joint_3', 'joint_4', 
            'joint_5', 'joint_6', 'joint_7'
        ]

        point1 = JointTrajectoryPoint()
        point1.positions = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        point1.time_from_start = Duration(sec=2, nanosec=0)

        point2 = JointTrajectoryPoint()
        point2.positions = [0.5, -0.5, 0.5, -0.5, 0.5, 0.01, -0.01]
        point2.time_from_start = Duration(sec=5, nanosec=0)

        goal_msg.trajectory.points.append(point1)
        goal_msg.trajectory.points.append(point2)
        
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg, feedback_callback=self.feedback_callback)

        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return

        self.get_logger().info('Goal accepted :)')
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)

    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Result: {result}')
        rclpy.shutdown()

    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f'Received feedback: {feedback.desired.positions}')


def main(args=None):
    rclpy.init(args=args)
    action_client = SimpleTrajectoryPublisher()
    action_client.send_goal()
    rclpy.spin(action_client)


if __name__ == '__main__':
    main()